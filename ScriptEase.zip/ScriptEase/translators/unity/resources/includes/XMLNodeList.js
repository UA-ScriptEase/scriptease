class XMLNodeList extends Array{

}